% 'plotSynthetic' function to CREATES SERIES OF SYNTHETIC SIGNALS with known periodicities which are resampled at the same time-points as the SO2 emission data at the selected volcano(es)
        % Four synthetic signals are created each including noise (using snr) and resampled to the range of SO2 emissions observed at the selected volcano(es):
        % Syn 1: with known periodicity equal to input value p1
        % Syn 2: with known periodicities equal to input values p2 and p3
        % Syn 3: with known periodicity equal to input values p1, p2 and p3
        % Random: no periodicity 
        % Function saves figure of each synthetic signal in the directory 'outDirSyn', <volcano_synthetic<number>.fig>
 
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged 
 
function [synthetic] = plotSynthetic(vName, dataSet, p1, p2, p3, snr, colSO2, colSyn, outDirSyn, outDirMat)
 
        % CREATES SYNTHETIC SIGNALS with each known periodicities according to inputs p1, p2 and p3
        s1 = cos(2 * pi *(dataSet(:,1)) / p1);
        s2 = cos(2 * pi *(dataSet(:,1)) / p2);
        s3 = cos(2 * pi *(dataSet(:,1)) / p3);
        
        % Creates strings for use in legend
        p1str = num2str(p1);
        p2str = num2str(p2);
        p3str = num2str(p3);
 
        % Combines signals to create synthetic signals with different combination of periodicities
        syn1 = s1; 
        syn2 = s2 + s3; 
        syn3 = s1 + s2 +s3; 
        
        % ADDS NOISE
        % Adds white Gaussian noise to the signal (to have the function measure the power of the sigma before adding noise, specify signalpower as 'measured')
        nsyn1 = awgn(syn1, snr, 'measured');
        nsyn2 = awgn(syn2, snr, 'measured');
        nsyn3 = awgn(syn3, snr, 'measured');
        
        % RESCALES DATA to match range of observed SO2 emissions 
        % 'rescale' scales the entries of an array to the interval [l,u]
        rnsyn1 = rescale(nsyn1, min(dataSet(:,2)), max(dataSet(:,2))); % Rescales synthetic signal between minimum and maximum observed SO2 emission rate 
        rnsyn2 = rescale(nsyn2, min(dataSet(:,2)), max(dataSet(:,2))); 
        rnsyn3 = rescale(nsyn3, min(dataSet(:,2)), max(dataSet(:,2)));
       
        % RANDOM SIGNAL, with no periodic function 
        rRandSyn = (max(dataSet(:,2))-min(dataSet(:,2))).*rand(length(dataSet(:,1)),1) + min(dataSet(:,2));
        
        % RESAMPLES DATASET 
        dp = isnan(dataSet(:,2)); % Returns index of '0' for dates where an SO2 emission rate is available 
        indDp = find(dp==0); % Returns row indices of all '0', corresponding to available data 
        
        % Creates new variable same length as data but with 4 columns, one for each synthetic signal 
        synthetic = zeros(length(dataSet(:,2)), 4); 
        
        % Populates new variable with resampled synthetic signals 
        synthetic(indDp, 1) = rnsyn1(indDp, :); 
        synthetic(indDp, 2) = rnsyn2(indDp, :); 
        synthetic(indDp, 3) = rnsyn3(indDp, :); 
        synthetic(indDp, 4) = rRandSyn(indDp, :); 
        
        % Converts '0' to NaN 
        synthetic(synthetic==0) = NaN;
         
        % FIGURE - PLOTS SYNTHETIC SPECTRA
        % Figure size 
        fx0 = 10;
        fy0 = 10;
        fwX = 1000;
        fhY = 1000;
                        
        figure % ('visible','off'); % SYNTHETIC SIGNAL 1
        box on
        set(gcf,'position',[fx0, fy0, fwX, fhY]);
        subplot(4,1,1) % Synthetic signal
        text(min(dataSet(:,1))+2,max(syn1)+1,'(a)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), syn1, '-'); hold on; s.Color = colSyn;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s day', p1str));    
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,2) % Synthetic spectra 1 with noise 
        text(min(dataSet(:,1))+2,max(nsyn1)+1,'(b)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), nsyn1, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s day + noise', p1str)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,3) % Rescaled
        text(min(dataSet(:,1))+2,22,'(c)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), rnsyn1, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('Rescaled %s day + noise (SNR = %d)', p1str, snr)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,4) % Resampled
        max1 = max(synthetic(:,1));
        max2 = max(dataSet(:,2));
        m = [max1, max2];
        MAX = max(m);
       
        text(min(dataSet(:,1))+2,22,'(d)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), synthetic(:,1), '.'); hold on; s.MarkerSize = 12; s.Color = colSyn; 
        v = plot(dataSet(:,1), dataSet(:,2), '.'); v.MarkerSize = 12; v.Color = colSO2;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude)'); 
        vn = string(vName);
        legend('Resampled', sprintf('%s',vn)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        % Saves figure
        saveas(Fig, fullfile(outDirSyn, sprintf('%s_synthetic1.fig', vn))); % Saves figure
            
        figure('visible','off'); % SYNTHETIC SIGNAL 2
        box on
        set(gcf,'position',[fx0, fy0, fwX, fhY]);
        subplot(4,1,1)
        text(min(dataSet(:,1))+2,max(syn1)+1,'(a)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), syn2, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s and %s day', p2str, p3str));    
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,2) 
        text(min(dataSet(:,1))+2,max(nsyn2)+1,'(b)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), nsyn2, '-'); hold on; s.Color = colSyn;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s and %s day + noise', p2str, p3str)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,3)
        text(min(dataSet(:,1))+2,22,'(c)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), rnsyn2, '-'); hold on; s.Color = colSyn;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('Rescaled %s and %s day + noise (SNR = %d)', p2str, p3str, snr)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,4)
        max1 = max(synthetic(:,2));
        max2 = max(dataSet(:,2));
        m = [max1, max2];
        MAX = max(m);
       
        text(min(dataSet(:,1))+2,22,'(d)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), synthetic(:,2), '.'); hold on; s.MarkerSize = 12; s.Color = colSyn; 
        v = plot(dataSet(:,1), dataSet(:,2), '.'); v.MarkerSize = 12; v.Color = colSO2;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude)'); 
        legend('Resampled', sprintf('%s',vn)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        % Saves figure
        saveas(Fig, fullfile(outDirSyn, sprintf('%s_synthetic2.fig', vn))); 
            
        figure % ('visible','off'); % SYNTHETIC SIGNAL 3
        box on
        set(gcf,'position',[fx0, fy0, fwX, fhY]);
        subplot(4,1,1)
        text(min(dataSet(:,1))+2,max(syn3)+1,'(a)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), syn3, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s, %s and %s day', p1str, p2str, p3str));    
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,2) 
        text(min(dataSet(:,1))+2,max(nsyn3)+1,'(b)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), nsyn3, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s, %s and %s day + noise', p1str, p2str, p3str)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,3)
        text(min(dataSet(:,1))+2,22,'(c)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), rnsyn3, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('Rescaled %s, %s and %s day + noise (SNR = %d)', p1str, p2str, p3str, snr)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,4)
        max1 = max(synthetic(:,3));
        max2 = max(dataSet(:,2));
        m = [max1, max2];
        MAX = max(m);
       
        text(min(dataSet(:,1))+2,22,'(d)','FontSize',10, 'FontWeight','bold');hold on;
        
        s = plot(dataSet(:,1), synthetic(:,3), '.'); hold on; s.MarkerSize = 12; s.Color = colSyn; 
        v = plot(dataSet(:,1), dataSet(:,2), '.'); v.MarkerSize = 12; v.Color = colSO2;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude)'); 
        legend('Resampled', sprintf('%s',vn)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        % Saves figure
        saveas(Fig, fullfile(outDirSyn, sprintf('%s_synthetic3.fig', vn))); 
            
        figure % ('visible','off'); % RANDOM SIGNAL
        fhYs = fhY/2;
        set(gcf,'position',[10, 10, 1000, fhYs]);
        subplot(2,1,1)
        text(min(dataSet(:,1))+2,max(rRandSyn)+1,'(a)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), rRandSyn, '-'); hold on; s.Color = colSyn;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('Random signal'));    
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(2,1,2)
        max1 = max(synthetic(:,4));
        max2 = max(dataSet(:,2));
        m = [max1, max2];
        MAX = max(m);
       
        text(min(dataSet(:,1))+2,22,'(d)','FontSize',10, 'FontWeight','bold');hold on;
        
        s = plot(dataSet(:,1), synthetic(:,4), '.'); hold on; s.MarkerSize = 12; s.Color = colSyn; 
        v = plot(dataSet(:,1), dataSet(:,2), '.'); v.MarkerSize = 12; v.Color = colSO2;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude)'); 
        legend('Resampled', sprintf('%s',vn)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w'); box on
 
       % SAVES FIGURE
       saveas(Fig, fullfile(outDirSyn, sprintf('%s_random.fig', vn)));
            
       % SAVES VARIABLES
       fname = fullfile(outDirMat, sprintf('%s_synthetic', vn)); % Defines name of results file according to volcano
       save(fname, 'vn', 'synthetic');       
 
       fprintf('Synthetic signal created and resampled with %s timestamp\n', vn') % Notifies user that .mat file created 
         
end

% 'plotSynthetic' function to CREATES SERIES OF SYNTHETIC SIGNALS with known periodicities which are resampled at the same time-points as the SO2 emission data at the selected volcano(es)
        % Four synthetic signals are created each including noise (using snr) and resampled to the range of SO2 emissions observed at the selected volcano(es):
        % Syn 1: with known periodicity equal to input value p1
        % Syn 2: with known periodicities equal to input values p2 and p3
        % Syn 3: with known periodicity equal to input values p1, p2 and p3
        % Random: no periodicity 
        % Function saves figure of each synthetic signal in the directory 'outDirSyn', <volcano_synthetic<number>.fig>
 
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged 
 
function [synthetic] = plotSynthetic(vName, dataSet, p1, p2, p3, snr, colSO2, colSyn, outDirSyn, outDirMat)
 
        % CREATES SYNTHETIC SIGNALS with each known periodicities according to inputs p1, p2 and p3
        s1 = cos(2 * pi *(dataSet(:,1)) / p1);
        s2 = cos(2 * pi *(dataSet(:,1)) / p2);
        s3 = cos(2 * pi *(dataSet(:,1)) / p3);
        
        % Creates strings for use in legend
        p1str = num2str(p1);
        p2str = num2str(p2);
        p3str = num2str(p3);
 
        % Combines signals to create synthetic signals with different combination of periodicities
        syn1 = s1; 
        syn2 = s2 + s3; 
        syn3 = s1 + s2 +s3; 
        
        % ADDS NOISE
        % Adds white Gaussian noise to the signal (to have the function measure the power of the sigma before adding noise, specify signalpower as 'measured')
        nsyn1 = awgn(syn1, snr, 'measured');
        nsyn2 = awgn(syn2, snr, 'measured');
        nsyn3 = awgn(syn3, snr, 'measured');
        
        % RESCALES DATA to match range of observed SO2 emissions 
        % 'rescale' scales the entries of an array to the interval [l,u]
        rnsyn1 = rescale(nsyn1, min(dataSet(:,2)), max(dataSet(:,2))); % Rescales synthetic signal between minimum and maximum observed SO2 emission rate 
        rnsyn2 = rescale(nsyn2, min(dataSet(:,2)), max(dataSet(:,2))); 
        rnsyn3 = rescale(nsyn3, min(dataSet(:,2)), max(dataSet(:,2)));
       
        % RANDOM SIGNAL, with no periodic function 
        rRandSyn = (max(dataSet(:,2))-min(dataSet(:,2))).*rand(length(dataSet(:,1)),1) + min(dataSet(:,2));
        
        % RESAMPLES DATASET 
        dp = isnan(dataSet(:,2)); % Returns index of '0' for dates where an SO2 emission rate is available 
        indDp = find(dp==0); % Returns row indices of all '0', corresponding to available data 
        
        % Creates new variable same length as data but with 4 columns, one for each synthetic signal 
        synthetic = zeros(length(dataSet(:,2)), 4); 
        
        % Populates new variable with resampled synthetic signals 
        synthetic(indDp, 1) = rnsyn1(indDp, :); 
        synthetic(indDp, 2) = rnsyn2(indDp, :); 
        synthetic(indDp, 3) = rnsyn3(indDp, :); 
        synthetic(indDp, 4) = rRandSyn(indDp, :); 
        
        % Converts '0' to NaN 
        synthetic(synthetic==0) = NaN;
         
        % FIGURE - PLOTS SYNTHETIC SPECTRA
        % Figure size 
        fx0 = 10;
        fy0 = 10;
        fwX = 1000;
        fhY = 1000;
                        
        figure % ('visible','off'); % SYNTHETIC SIGNAL 1
        box on
        set(gcf,'position',[fx0, fy0, fwX, fhY]);
        subplot(4,1,1) % Synthetic signal
        text(min(dataSet(:,1))+2,max(syn1)+1,'(a)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), syn1, '-'); hold on; s.Color = colSyn;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s day', p1str));    
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,2) % Synthetic spectra 1 with noise 
        text(min(dataSet(:,1))+2,max(nsyn1)+1,'(b)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), nsyn1, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s day + noise', p1str)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,3) % Rescaled
        text(min(dataSet(:,1))+2,22,'(c)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), rnsyn1, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('Rescaled %s day + noise (SNR = %d)', p1str, snr)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,4) % Resampled
        max1 = max(synthetic(:,1));
        max2 = max(dataSet(:,2));
        m = [max1, max2];
        MAX = max(m);
       
        text(min(dataSet(:,1))+2,22,'(d)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), synthetic(:,1), '.'); hold on; s.MarkerSize = 12; s.Color = colSyn; 
        v = plot(dataSet(:,1), dataSet(:,2), '.'); v.MarkerSize = 12; v.Color = colSO2;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude)'); 
        vn = string(vName);
        legend('Resampled', sprintf('%s',vn)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        % Saves figure
        saveas(Fig, fullfile(outDirSyn, sprintf('%s_synthetic1.fig', vn))); % Saves figure
            
        figure('visible','off'); % SYNTHETIC SIGNAL 2
        box on
        set(gcf,'position',[fx0, fy0, fwX, fhY]);
        subplot(4,1,1)
        text(min(dataSet(:,1))+2,max(syn1)+1,'(a)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), syn2, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s and %s day', p2str, p3str));    
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,2) 
        text(min(dataSet(:,1))+2,max(nsyn2)+1,'(b)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), nsyn2, '-'); hold on; s.Color = colSyn;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s and %s day + noise', p2str, p3str)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,3)
        text(min(dataSet(:,1))+2,22,'(c)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), rnsyn2, '-'); hold on; s.Color = colSyn;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('Rescaled %s and %s day + noise (SNR = %d)', p2str, p3str, snr)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,4)
        max1 = max(synthetic(:,2));
        max2 = max(dataSet(:,2));
        m = [max1, max2];
        MAX = max(m);
       
        text(min(dataSet(:,1))+2,22,'(d)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), synthetic(:,2), '.'); hold on; s.MarkerSize = 12; s.Color = colSyn; 
        v = plot(dataSet(:,1), dataSet(:,2), '.'); v.MarkerSize = 12; v.Color = colSO2;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude)'); 
        legend('Resampled', sprintf('%s',vn)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        % Saves figure
        saveas(Fig, fullfile(outDirSyn, sprintf('%s_synthetic2.fig', vn))); 
            
        figure % ('visible','off'); % SYNTHETIC SIGNAL 3
        box on
        set(gcf,'position',[fx0, fy0, fwX, fhY]);
        subplot(4,1,1)
        text(min(dataSet(:,1))+2,max(syn3)+1,'(a)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), syn3, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s, %s and %s day', p1str, p2str, p3str));    
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,2) 
        text(min(dataSet(:,1))+2,max(nsyn3)+1,'(b)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), nsyn3, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('%s, %s and %s day + noise', p1str, p2str, p3str)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,3)
        text(min(dataSet(:,1))+2,22,'(c)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), rnsyn3, '-'); hold on; s.Color = colSyn; 
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('Rescaled %s, %s and %s day + noise (SNR = %d)', p1str, p2str, p3str, snr)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(4,1,4)
        max1 = max(synthetic(:,3));
        max2 = max(dataSet(:,2));
        m = [max1, max2];
        MAX = max(m);
       
        text(min(dataSet(:,1))+2,22,'(d)','FontSize',10, 'FontWeight','bold');hold on;
        
        s = plot(dataSet(:,1), synthetic(:,3), '.'); hold on; s.MarkerSize = 12; s.Color = colSyn; 
        v = plot(dataSet(:,1), dataSet(:,2), '.'); v.MarkerSize = 12; v.Color = colSO2;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude)'); 
        legend('Resampled', sprintf('%s',vn)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        % Saves figure
        saveas(Fig, fullfile(outDirSyn, sprintf('%s_synthetic3.fig', vn))); 
            
        figure % ('visible','off'); % RANDOM SIGNAL
        fhYs = fhY/2;
        set(gcf,'position',[10, 10, 1000, fhYs]);
        subplot(2,1,1)
        text(min(dataSet(:,1))+2,max(rRandSyn)+1,'(a)','FontSize',10, 'FontWeight','bold');hold on;
        s = plot(dataSet(:,1), rRandSyn, '-'); hold on; s.Color = colSyn;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude'); 
        legend(sprintf('Random signal'));    
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w');
 
        subplot(2,1,2)
        max1 = max(synthetic(:,4));
        max2 = max(dataSet(:,2));
        m = [max1, max2];
        MAX = max(m);
       
        text(min(dataSet(:,1))+2,22,'(d)','FontSize',10, 'FontWeight','bold');hold on;
        
        s = plot(dataSet(:,1), synthetic(:,4), '.'); hold on; s.MarkerSize = 12; s.Color = colSyn; 
        v = plot(dataSet(:,1), dataSet(:,2), '.'); v.MarkerSize = 12; v.Color = colSO2;
        xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
        ylabel('Magnitude)'); 
        legend('Resampled', sprintf('%s',vn)); 
        Fig = gca; Fig.FontSize = 12; set(gcf,'color','w'); box on
 
       % SAVES FIGURE
       saveas(Fig, fullfile(outDirSyn, sprintf('%s_random.fig', vn)));
            
       % SAVES VARIABLES
       fname = fullfile(outDirMat, sprintf('%s_synthetic', vn)); % Defines name of results file according to volcano
       save(fname, 'vn', 'synthetic');       
 
       fprintf('Synthetic signal created and resampled with %s timestamp\n', vn') % Notifies user that .mat file created 
         
end