% 'plotLsSO2' function PLOTS MEDIAN PSD for SO2 EMISSION WITH STANDARD DEVIATION 
        % This function saves a variable containing the frequencies at which the PSD of SO2 emission crosses the corresponding Pd value (sigV)
        % Converts frequency data to period (days)
        % Displays periodicities within Nf and lim (for example, 2 days to number of days equal to 4 cycles per time series) 
        % Function saves figure in the directory 'outDirFig', <volcano_LsSO2.fig>
 
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged  
 
function [asp, fap] = plotLsSO2(vn, fMasterBs, dataSet, msdMaster, colSD, colSO2, pthMasterBs, lim, deltaT, Nf, Pd, outDirFig, x0, y0, height, width, asp, fap)
        
        subplot(1,2,asp)
        p = 1; % Parameter 1 (SO2)
       
        % FIGURE
        [valN, ~,~] = size(fMasterBs);
       
        t = ones(valN, 1); 
        freq = fMasterBs(:,1,1);
        x = t./freq;
        y = msdMaster(:,1,p);
        dy = msdMaster(:,2,p); 
        fill([x;flipud(x)],[y-dy;flipud(y+dy)],colSD,'linestyle','none', 'linewidth', 2);hold on; 
        e = line(x,y); e.Color = colSO2; e.LineWidth = 1;
        ylabel(sprintf('Lomb-Scargle\nPSD estimate'));
        %ylim([0 18]); 
        Fig = gca; Fig.FontSize = 14; Fig.XMinorTick = 'on';
        set(gcf,'color','w');
        a = yline(pthMasterBs(1,p,p),':'); a.Color = [0.5 0 0.1]; a.LineWidth = 1;hold on;
        b = yline(pthMasterBs(2,p,p),'--'); b.Color = [0.5 0 0.1]; b.LineWidth = 1;
        c = yline(pthMasterBs(3,p,p),'-'); c.Color = [0.7 0 0]; c.LineWidth = 1;
        d = yline(pthMasterBs(4,p,p),'-'); d.Color = [1 0 0]; d.LineWidth = 1;
        cy = length(dataSet)/lim;
        xlim([min(deltaT/Nf) max(cy)]); xlabel('Period');
        title(sprintf('%s', vn)); 
        %text(cy-40 * [1 1 1 1], pthMasterBs(:,p,p)+.3, [num2str((((Pd)') * 100)), repmat('%', [4,1])], 'FontSize', 14);
        % set(gcf,'position',[x0,y0,width,height])
        Fig = gca; Fig.FontSize = 9; Fig.XMinorTick = 'on';
       % Saves figure
            %saveas(Fig, fullfile(outDirFig, sprintf('%s_LsSO2.fig', vn))); % Saves figure
            set(gca, 'XScale', 'log')
       %fprintf('Lomb-Scargle periodogram for %s SO2 saved\n', vn) % 
        
       asp = asp+1;
       
       thisfap = pthMasterBs(:,p,p); 
       fap =[fap, thisfap];
       
end 