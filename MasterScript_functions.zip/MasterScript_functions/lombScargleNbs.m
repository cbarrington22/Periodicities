% lombScargleNbs'function to CALCULATES LOMB-SCARGLE POWER SPECTRAL DENSITY OF NON-BOOTSTRAPPED DATA (PSD) and FALSE ALARM PROBABILITIES (FAP) defined by Pd for all parameters in <volcano_nbsMatrix.mat>
       % This function uses the 'plomb' function with the maximum frequency (Nf) and oversampling factor (ofac) defined 
            % It checks the returned frequency grid and false alarm probability thresholds are equal across parameters 
            % This function calculates the PSD for all parameters contained in <volcano_nbsMatrix.mat> and saves it in <volcano_psdLS.mat>         
           
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged 
 
function [] = lombScargleNbs(nbsMatrix, dataSet, Nf, ofac, Pd, vn, outDirMat, ext2nbs)
 
         % PRE-ALLOCATES SPACE
         % Determines sizes and pre-allocates space 
         [~, ncol, npages] = size(nbsMatrix); % Determines number of columns and number of pages for 3D array 
 
         % Runs Lomb-Scargle analysis once to obtain size of output parameters 
         % For the first bootstrapped sample and the first parameter, calculates Lomb Scargle power spectral density and false alarm probability thresholds  
         [pxx, f, pth] = plomb(nbsMatrix(:,1,1), dataSet(:,1), Nf, ofac, 'normalized', 'Pd', Pd); 
        
         % Pre-allocates space for PSD ouput 
         pxxMasterNbs = zeros(length(pxx), ncol); pxxMasterNbs(:,:,npages) = zeros(size(pxxMasterNbs));
 
         % Pre-allocates space for frequency grid output 
         fMasterNbs = zeros(length(f), ncol); fMasterNbs(:,:,npages) = zeros(size(fMasterNbs));
        
         % Pre-allocates space for false alarm probability thresholds output 
         pthMasterNbs = zeros(length(pth), ncol); pthMasterNbs(:,:,npages) = zeros(size(pthMasterNbs));
 
         % CALCULATES PSD
         for pg = 1:npages % For each parameter 
             for c = 1:ncol % And each bootstrapped sample
                 % Calculates Lomb-Scargle periodogram and stores PSD, frequency grid and FAP threshold data
                 [pxxMasterNbs(:, c, pg), fMasterNbs(:, c, pg), pthMasterNbs(:, c, pg)] = plomb(nbsMatrix(:, c, pg), dataSet(:,1), Nf, ofac, 'normalized', 'Pd', Pd); 
             end  
         end 
        
         % CHECK RETURNED FREQUENCY GRID AND FAP THRESHOLDS ARE THE SAME FOR ALL PARAMETERS 
         % isequal(A,B) returns logical 1 (TRUE) if arrays A and B are the same size and contain the same values
         tf = isequal(fMasterNbs(:,:,1), fMasterNbs(:,:,npages)); % Frequency grid 
         tp = isequal(pthMasterNbs(:,:,1), pthMasterNbs(:,:,npages)); % Checks FAP thresholds
       
         if tf == 1 && tp == 1 % If frequency grid and FAP thresholds are the same across parameters
            % Saves variables as .mat file 
            fname = fullfile(outDirMat, sprintf('%s%s', vn, ext2nbs)); % Defines name of results file according to volcano
            save(fname, 'vn', 'dataSet', 'pxxMasterNbs', 'fMasterNbs', 'pthMasterNbs');       
            fprintf('Lomb-Scargle complete for non-bootstrapped paramaters at %s\n', vn); % Notifies user that .mat file created 
        else  
            fprintf('Warning: Frequency grid and FAP thresholds for %s not equal for all parameters.. .mat file not saved\n', vn);  
        end       
end 