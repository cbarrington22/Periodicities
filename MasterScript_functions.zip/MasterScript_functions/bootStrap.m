% 'bootStrap' function to loop through all parameters in the dataset which are reported as a daily mean with standard deviation and RESAMPLES them using random numbers between the minimum (daily mean - standard deviation) and maximum (daily mean + standard deviation) values  
        % Function saves resampled data as 3D matrix, <volcano_bsMatrix.mat>:
            % Rows: each day (length of time series)
            % Column: each run (defined by nRuns)
            % Page: each parameter where:
                % 1: Daily mean of observed SO2 flux
                % 2: Daily mean of used plume speed
                % 3: Daily mean of observed plume direction
                % 4: Daily mean of observed plume altitude
                % 5: Daily mean of observed distance to plume
                % 6: Daily mean of plume width scanned by the instrument
                % 7: Daily mean of modeled cloud cover at summit altitude
            % This function saves non-resampled data as a 2D matrix, <volcano_nbsMatrix.mat>:
                % Number of total scan measurements on each day
                % Number of valid SO2 flux measurements on each day
                
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged 
 
function [] = bootStrap(vn, dataSet, nRuns, outDirFigBS, outDirMat, ext1bs, ext1nbs)
        
            % PRE-ALLOCATES SPACE to variables used in loop 
            % Bootstrapped variables
            bsMatrix = zeros(length(dataSet(:,1)), nRuns); % Creates 2D array length of dataset x number resampled datasets 
            bsMatrix(:,:,7) = zeros(length(dataSet(:,1)), nRuns); % Creates 3D array, with one page per variable 
            % Non-bootstrapped variables 
            nbsMatrix = zeros(length(dataSet(:,1)), 1); % Creates 2D array length of dataset
            nbsMatrix(:,:,2) = zeros(length(dataSet(:,1)), 1); % Creates 3D array, with one page per variable 
             
            % LOOPS THROUGH EACH PARAMETER to be resampled 
            for par = [2, 7, 9, 11, 13, 15, 17] % For all parameters that have corresponding standard deviation 
                % Check against: 
                % Data files from NOVAC database (https://novac.chalmers.se/):
                % Column 1 - Date_UT_[YYMMDD]:                              Date of measurements
                % Column 2 - SO2_flux_(daily_mean)_[kg s-1]:                Daily mean of observed SO2 flux - YES
                % Column 3 - SO2_flux_(daily_s.d.)_[kg s-1]:                Daily s.d of observed SO2 flux
                % Column 4 - SO2_flux_(daily_25%)_[kg s-1]:                 Daily first quartile of observed SO2 flux 
                % Column 5 - SO2_flux_(daily_50%)_[kg s-1]:                 Daily second quartile of observed SO2 flux
                % Column 6 - SO2_flux_(daily_75%)_[kg s-1]:                 Daily third quartile of observed SO2 flux
                % Column 7 - SO2_plume_speed_(daily_mean)_[m s-1]:          Daily mean of used plume speed - YES
                % Column 8 - SO2_plume_speed_(daily_s.d.)_[m s-1]:          Daily s.d. of used plume speed
                % Column 9 - SO2_plume_direction_(daily_mean)_[deg]:        Daily mean of observed plume direction - YES 
                % Column 10 - SO2_plume_direction_(daily_s.d.)_[deg]:       Daily s.d. of observed plume direction 
                % Column 11 - SO2_plume_altitude_(daily_mean)_[m asl]:      Daily mean of observed plume altitude - YES
                % Column 12 - SO2_plume_altitude_(daily_s.d.)_[m asl]:      Daily s.d. of observed plume altitude
                % Column 13 - SO2_plume_distance_(daily_mean)_[m]:          Daily mean of observed distance to plume - YES
                % Column 14 - SO2_plume_distance_(daily_s.d.)_[m]:          Daily s.d. of observed distance to plume
                % Column 15 - SO2_plume_width_(daily_mean)_[m]:             Daily mean of plume width scanned by the instrument(s) - YES
                % Column 16 - SO2_plume_width_(daily_s.d.)_[m]:             Daily s.d. of plume width scanned by the instrument(s)
                % Column 17 - Cloud_cover_(daily_mean)_[%]:                 Daily mean of modeled cloud cover at summit altitude - YES
                % Column 18 - Cloud_cover_(daily_s.d.)_[%]:                 Daily s.d. of modeled cloud cover at summit altitude
                % Column 19 - Total_number_of_measurements:                 Number of total scan measurements on each day
                % Column 20 - Valid_number_of_measurements:                 Number of valid SO2 flux measurements on each day    
               
                % ** IMPORTANT ** 
                % 'par' refers to 'parameter' indicated by column in dataSet 
                % 'pg' refers to the 'page' in bsMatrix 
                % For example, 'par = 2' refers to the second column in dataSet which is 'daily mean of observed SO2 flux', which will be assigned 'pg = 1', and stored in the first page of bsMatrix
                if par == 2 % Parameter
                     pg = 1; % Page of 3D array 
                     parStr = "SO_2 emission rate"; % Y-axis display 
                     parStrUn = "kg s^-^1"; % Unit display 
                     parStrFn = "SO2"; % String for filename 
                elseif par == 7
                     pg = 2;
                     parStr = "plume speed";
                     parStrUn = "m s^-^1";
                     parStrFn = "pSpeed";
                elseif par == 9
                     pg = 3;
                     parStr = "plume direction";
                     parStrUn = "deg";
                     parStrFn = "pDir";
                elseif par == 11
                     pg = 4;
                     parStr = "plume altitude";
                     parStrUn = "m asl";
                     parStrFn = "pAlt";
                elseif par == 13
                     pg = 5;
                     parStr = "distance to plume";
                     parStrUn = "m";
                     parStrFn = "pDist";
                elseif par == 15
                     pg = 6;
                     parStr = "plume width";
                     parStrUn = "m";
                     parStrFn = "pWidth";
                elseif par == 17
                     pg = 7;
                     parStr = "cloud cover";
                     parStrUn = "%";
                     parStrFn = "cloudCov";
                end 
 
                % DETERMINES MINIMUM AND MAXIMUM RANGE of resampling 
                iMin = dataSet(:,par) - dataSet(:, par + 1); % Standard deviation is the next column 
                iMax =  dataSet(:,par) + dataSet(:, par + 1); 
                
                % SPECIAL CASE OF CLOUD COVER 
                % Daily mean cloud cover - standard deviation is sometimes <0 creating a different sized pxx when using 'plomb'
                if par == 17 % For the case of cloud cover 
                   iMin(iMin<0) = 0; % If the minimum value is <0, set to 0 
                end        
                   
                % RESAMPLES DATA 
                % FIGURE – plots resampled data (sanity check)
                figure('visible','off');
                for bsS = 1:nRuns % For all number of bootstrap samples 
                    for dpS = 1:length(dataSet(:,1)) % For each datapoint in timeseries
                        % Fill the datapoint (dpS) value of the bootstrap sample (bsS) for parameter (par) with random sample between min and maximum values 
                        bsMatrix(dpS, bsS, pg) = iMin(dpS, :) + (iMax(dpS, :) - iMin(dpS, :)).* rand(1, 1); 
                        % SPECIAL CASE OF PLUME DIRECTION 
                        % This parameter is not continuous (-180 to 180 deg.), i.e., plume direction of 176 deg. +/- 40 deg. IS NOT 216 to 136 but -144 to 136 
                        if par == 9 % If parameter is daily mean of used plume speed
                            if bsMatrix(dpS, bsS, pg) < -180 % If the value is less than -180
                                        bsMatrix(dpS, bsS, pg) = bsMatrix(dpS, bsS, pg) + 360; % Add 360 degrees to value 
                            elseif bsMatrix(dpS, bsS, pg) > 180 % If the value is greater than 180 
                                         bsMatrix(dpS, bsS, pg) = bsMatrix(dpS, bsS, pg) - 360; % Subtract 360 degrees from value    
                            end 
                        end
                    end 
                    plot(dataSet(:,1), bsMatrix(:, bsS, pg), '.'); hold on % Plots resampled data 
                end 
                xlim([min(dataSet(:,1)) max(dataSet(:,1))]); datetick('x', 'yyyy', 'keeplimits'); % xlabel('Date (yyyy)');
                ylabel(sprintf('Resampled data %s (%s)', parStr, parStrUn));
                Fig = gca; Fig.FontSize = 14; set(gcf,'color','w'); 
                legend(sprintf('%s %s', vn, parStr)); 
                % SAVES FIGURE
                saveas(Fig, fullfile(outDirFigBS, sprintf('%s_bsSampled_%s.fig', vn, parStrFn))); 
 
           end 
           % NON-BOOTSTRAPPED PARAMETERS
           nbsMatrix(:,:,1) = dataSet(:,19); % Saves number of total scan measurements on each day
           nbsMatrix(:,:,2) = dataSet(:,20);  % Saves number of valid SO2 flux measurements on each day
 
           % SAVES VARIABLES 
           % Bootstrapped
           fname = fullfile(outDirMat, sprintf('%s%s', vn, ext1bs)); % Defines name of results file according to volcano
           save(fname, 'vn', 'bsMatrix', 'dataSet');  % Saves bootstrapped data         
           % Non-bootstrapped
           fname = fullfile(outDirMat, sprintf('%s%s', vn, ext1nbs)); % Defines name of results file according to volcano
           save(fname, 'vn', 'nbsMatrix', 'dataSet'); % Saves non-bootstrapped data   
 
          fprintf('Bootrapping complete for %s!\n', vn) % Notifies user that .mat file created 
 
end 