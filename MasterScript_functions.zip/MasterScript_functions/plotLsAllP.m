 % 'plotLsAllP' function PLOTS MEDIAN PSD WITH STANDARD DEVIATION FOR ALL PARAMETERS included in <volcano_msdLS.mat> and calculated PSD for parameters included in <volcano_psdLS.mat>
        % This function plots an x-line at the frequencies contained in sigV, across all plots 
        % Function saves figure in the directory 'outDirFig', <volcano_LsAll.fig>
 
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged 
 
function [] = plotLsAllP(vn, fMasterBs, dataSet, fMasterNbs, pthMasterNbs, pthMasterBs, msdMaster, pxxMasterNbs, colSel, deltaT, Nf, colSD, lim, x0, y0, wX, hY, outDirFig)
        
         STRINGS = strcat({'Emission rate','Plume speed', 'Plume direction', 'Distance to plume','Plume width', 'Cloud cover', 'Total measurements', 'Valid measurements', 'Plume altitude'});
 
         % CHECK RETURNED FREQUENCY GRID AND FAP THRESHOLDS ARE THE SAME FOR BOOTSTRAPPED AND NON-BOOTSTRAPPED PARAMETERS
         % isequal(A,B) returns logical 1 (TRUE) if arrays A and B are the same size and contain the same values
         tf = isequal(fMasterBs(:,1,1), fMasterNbs(:,:,1)); % Frequency grid 
         tp = isequal(pthMasterBs(:,1,1), pthMasterNbs(:,:,1)); % Checks FAP thresholds
         
         % COLOURS for plotting
         % colSel = [colSO2; colplumespeed; colplumedir; colalt; coldist; colwidth; colcloud; coltotalnum; colvalmeas];
         
         cy = length(dataSet)/lim;
            
         M = max(msdMaster,[],'all');
         Msd = max(msdMaster(:,2,:)); Msd = max(Msd,[],'all');
         % MAX = M + Msd; 
         MAX = 75;
               
         % if p == 1
         % SO2 = msdMaster(:,1,1); % Extracts median SO2 psd
         % [~, FREQ] = max(SO2); % Returns position of maximum so2 psd
         % [I,~,~] = find((SO2)>=(pthMasterBs(1,1,1))); % 
         % so2IN = SO2(I,:);
         % Finds corresponding frequency
         % FREQ = fMasterBs(FREQ,1,1);
         % FREQ = fMasterBs(so2IN,1,1);
         % freqq = ones(length(so2IN), 1);
         % Xf = freqq./FREQ; % converts to period
         % Xf1 = 50.5586; 
         % Xf2 = 99.2446; 
 
         if tf == 1 && tp == 1 % If frequency grid and FAP thresholds are the same across bootstrapped and non-bootstrapped parameters
            f = fMasterBs(:,1,1); % Frequency data 
            t = ones(length(f), 1); 
            x = t./f;
            % Combines PSD data 
            figure; % FIGURE – PLOTS PSSD FOR ALL PARAMETERS
            for p = [1,2,3,4,5,6,7,8,9] % For all parameters except 4 (altitude)
                % subplot(9, 1, p)
                if p == 5 || p == 6 || p == 7 || p == 8 || p == 9
                   supP = p-1; 
                   % if altitude 
                elseif p == 4 
                    supP = 9;  
                else 
                   supP = p; 
                end 
                subplot(9, 1, supP)   
                if p == 1 || p == 2 || p == 3 || p == 5 || p == 6 || p == 7  % For all parameters with standard deviation (i.e., bootstrapped) 
                    y = msdMaster(:,1,p);
                    % if p == 1
                    %      maximum = msdMaster(:,1,p);
                    %  end 
                    dy = msdMaster(:,2,p); 
                    fill([x;flipud(x)],[y-dy;flipud(y+dy)], colSD,'linestyle','none', 'linewidth', 2);hold on; 
                    res = line(x,y); hold on; res.LineWidth = 1;
                    a = yline(pthMasterBs(1,1,p),':'); a.Color = [0.5 0 0.1]; a.LineWidth = 1;hold on;
                    b = yline(pthMasterBs(2,1,p),'--');b.Color = [0.5 0 0.1]; b.LineWidth = 1;
                    c = yline(pthMasterBs(3,1,p),'-'); c.Color = [0.7 0 0]; c.LineWidth = 1;
                    d = yline(pthMasterBs(4,1,p),'-'); d.Color = [1 0 0]; d.LineWidth = 1;
                    set(gca,'XTickLabel',[]);
                    ylim([0 MAX]);
                    text(2.1,MAX+7,STRINGS(supP),'FontSize',10, 'FontWeight','bold');
                    set(gca, 'XScale', 'log')
                    if p == 1
                        % labP1 = string(round(Xf1, 0));labP2 = string(round(Xf2, 0));
                        % ST1 = sprintf('%s-days', labP1);
                        % ST2 = sprintf('%s-days', labP2);
                        % xl = xline(Xf1, '-', {ST1}, 'LabelOrientation', 'horizontal'); xl.Color = [0.15 0.15 0.15]; 
                        % xl.FontSize = 10; 
                        % xl = xline(Xf2, '-', {ST2}, 'LabelOrientation', 'horizontal'); xl.Color = [0.15 0.15 0.15]; 
                        % ST3 = sprintf('Mf');
                        xl = xline(13.661, '--'); xl.Color = [0.15 0.15 0.15]; 
                        % xl = xline(Xf1, '-'); xl.Color = [0.4 0.3 0.3]; 
                    else 
                        %xl = xline(Xf1, '-'); xl.Color = [0.15 0.15 0.15]; 
                        % xl = xline(Xf2, '-'); xl.Color = [0.15 0.15 0.15]; 
                    end
                    % xlim([min(deltaT/Nf) max(cy)]);
                    % set(gca,'XTickLabel',[]);
                    % set(gca,'XTick',[])
                    % set(gca, 'XScale', 'log')
                    % set(gca,'FontSize',14) 
                    % dim = [0.2 0.5 0.3 0.3];
                    % str = sprintf('%s', strPar(p,:));
                    % annotation('textbox',dim,'String',str,'FitBoxToText','off');
                elseif p == 8 || p == 9 % For all parameters without standard deviation (i.e. non-bootstrapped)  
                    y = pxxMasterNbs(:,1,p-7);
                    dy = zeros(length(msdMaster), 1);
                    fill([x;flipud(x)],[y-dy;flipud(y+dy)], colSD,'linestyle','none', 'linewidth', 2);hold on; 
                    res = line(x,y); hold on; res.LineWidth = 1;
                    a = yline(pthMasterNbs(1,1,p-7),':'); a.Color = [0.5 0 0.1]; a.LineWidth = 1;hold on;
                    b = yline(pthMasterNbs(2,1,p-7),'--'); b.Color = [0.5 0 0.1]; b.LineWidth = 1;
                    c = yline(pthMasterNbs(3,1,p-7),'-'); c.Color = [0.7 0 0]; c.LineWidth = 1;
                    d = yline(pthMasterNbs(4,1,p-7),'-'); d.Color = [1 0 0]; d.LineWidth = 1;
                    xlim([min(deltaT/Nf) max(cy)]); 
                    ylim([0 MAX]);
                    text(2.1,MAX+7,STRINGS(supP),'FontSize',10, 'FontWeight','bold');
                    % xl = xline(Xf1, '-'); xl.Color = [0.15 0.15 0.15]; 
                    % xl = xline(Xf2, '-'); xl.Color = [0.15 0.15 0.15]; 
                    xtickformat('%.0f')
                    set(gca, 'XScale', 'log')
                    figg = gca; 
                    xx = figg.XTick;
                    set(gca,'XTickLabel',sprintf('%d', xx(1,1)))
                    % if p == 8 
                       set(gca,'XTickLabel',[]);
                    % end 
                    
                elseif p ==4 
                    y = msdMaster(:,1,p);
                    % if p == 1
                    %      maximum = msdMaster(:,1,p);
                    % end 
                    dy = msdMaster(:,2,p); 
                    fill([x;flipud(x)],[y-dy;flipud(y+dy)], colSD,'linestyle','none', 'linewidth', 2);hold on; 
                    res = line(x,y); hold on; res.LineWidth = 1;
                    a = yline(pthMasterBs(1,1,p),':'); a.Color = [0.5 0 0.1]; a.LineWidth = 1;hold on;
                    b = yline(pthMasterBs(2,1,p),'--');b.Color = [0.5 0 0.1]; b.LineWidth = 1;
                    c = yline(pthMasterBs(3,1,p),'-'); c.Color = [0.7 0 0]; c.LineWidth = 1;
                    d = yline(pthMasterBs(4,1,p),'-'); d.Color = [1 0 0]; d.LineWidth = 1;
                    % set(gca,'XTickLabel',[]);
                    ylim([0 MAX]);
                    text(2.1, MAX+7,STRINGS(supP),'FontSize',10, 'FontWeight','bold');
                    set(gca, 'XScale', 'log')
                end 
                xlim([min(deltaT/Nf) max(cy)]); 
                  
              % if p == 8
              %      xlabel('Period (days)'); 
              %      set(gca,'XTick',[]')
              %    set(gca,'XTickLabel',[]);
              %    set(gca,'FontSize',14) 
              % elseif p == 9 
              % xlabel('Period (days)'); 
              % set(gca,'FontSize',14) 
              %  end 
              % set(gca, 'XScale', 'log')
              % elseif p == 4
              % SPECIAL CASE PLUME ALTITUDE
              % end
            res.Color = colSel(p,:); set(gca, 'XScale', 'log')
            Fig = gca;
            Fig.XMinorTick = 'on';
            % M = max(msdMaster,[],'all');
            % Msd = max(msdMaster(:,2,:));Msd = max(Msd,[],'all');
            % MAX = M +Msd;
            % ylim([0 MAX]);
            set(gca,'FontSize',14) 
            end
            % ylabel('PSD estimate');
            set(gcf,'color','w');
            % set(gcf,'position',[x0,y0,wX,hY])  
            % xlabel('Period (days)');
            % h4 = subplot(9,1,4); 
            % delete(h4);
            % han=axes(fig,'visible','off'); 
            % han.Title.Visible='on';
            % han.XLabel.Visible='on';
            % han.YLabel.Visible='on';
            % ylabel(han,'PSD estimate');
            % xlabel(han,'Period (days)');
            % title(han,'yourTitle');
            % set(gca,'FontSize',14) 
            Fig = gcf; 
            han=axes(Fig,'visible','off'); 
            han.Title.Visible='on';
            han.XLabel.Visible='on';
            han.YLabel.Visible='on';
            ylabel(han,'Lomb-Scargle PSD estimate'); han.FontSize = 14; 
            xlabel(han, sprintf('Period (days)\n\n'));
            stringgg = 'Galeras'; % sprintf('%s', vn);
            title(han,stringgg);
            han.FontSize = 14; 
            
            % ADDING LABELS 
            % STRINGS = strcat({'Emission rate','Plume speed', 'Plume direction', 'Distance to plume','Plume width', 'Cloud cover', 'Total number of measurements', 'Valid measurements'});
            % text(max(cy)+50,MAX/2,STRINGS,'Units','normalized','FontSize',12)
            % text(50,10,STRINGS(,'Units','normalized','FontSize',20)
            % test = {'test'};
            % text(50, 10, test)
         else
            fprintf('Warning: Frequency grid and FAP thresholds for %s not equal for all parameters.. .mat file not saved\n', vn);  
         end
        
        % SAVES FIGURE
        saveas(gcf, fullfile(outDirFig, sprintf('%s_LsAll.fig', vn))); % Saves figure
            
        fprintf('Lomb-Scargle periodogram for %s SO2 saved\n', vn) % 
             
end 