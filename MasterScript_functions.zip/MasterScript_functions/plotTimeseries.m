% 'plotTimeseries' function to load data files and if more than 8-days of data exist (based on minimum period 2-day and minimum number of cycles 4), PLOTS TIME SERIES OF SO2 EMISSIONS (daily mean +/- standard deviation) with volcanic activity 
        % Saves the following information <volcano>.mat in the directory 'outDirMat': 
            % Start date, end date and number of datapoints included in NOVAC database 
            % Dataset including: 
                % 1. Date 
                % 2. Daily mean of observed SO2 flux
                % 3. Daily s.d of observed SO2 flux
                % 4. Daily first quartile of observed SO2 flux
                % 5. Daily second quartile of observed SO2 flux
                % 6. Daily second quartile of observed SO2 flux
                % 7. Daily mean of used plume speed
                % 8. Daily s.d. of used plume speed
                % 9. Daily mean of observed plume direction
                % 10. Daily s.d. of observed plume direction
                % 11. Daily mean of observed plume altitude
                % 12. Daily s.d. of observed plume altitude
                % 13. Daily mean of observed distance to plume
                % 14. Daily s.d. of observed distance to plume
                % 15. Daily mean of plume width scanned by the instrument(s)
                % 16. Daily s.d. of plume width scanned by the instrument(s)
                % 17. Daily mean of modeled cloud cover at summit altitude
                % 18. Daily s.d. of modeled cloud cover at summit altitude
                % 19. Number of total scan measurements on each day
                % 20. Number of valid SO2 flux measurements on each day
         % Function saves figure in the directory 'outDirFig', <volcano_timeseriesSO2.fig>
         
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged          
 
function [asp] = plotTimeseries(inDirNovac, vName, formatInNovac, fileTypeGvp, dirGvp, formatInGVP, colSO2, minWidth, colVEI, x0, y0, wX, hY, outDirFig, outDirMat, asp)
 
        % LOADS DATA 
        [date, dailymean, dailysd, daily25, daily50, daily75, plumespeedmean, plumespeedsd, plumedirmean, plumedirsd, plumealtmean, plumealtsd, plumedistmean, plumedistsd, plumewidthmean, plumewidthsd, cloudcovmean, cloudcovsd, totmeas, validmeas] = textread(inDirNovac,'%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f'); % Loads data
        dateStr = string(date); date = datenum(dateStr, formatInNovac); % Converts date to string and then to numeric form based on format 
        N = length(date); % Determines number of datapoints 
 
        % DETERMINES IF NUMBER OF DATAPOINTS IS SUFFICIENT  
        if N >= 8 % Continues with analysis if more than 4 datapoints  
   
            % CREATES TIMESERIES WITH 1-DATAPOINT PER DAY BETWEEN START AND END DATE
            startDate = min(date); endDate = max(date); % Finds first and last date of data
            timeseries = (startDate:1:endDate)'; % Creates vector with days between start and end of dataSet 
            dateInd = ismember(timeseries, date); % Returns index of days which have corresponding emissions data 
            dataSet = zeros(length(timeseries), 20); % Creates new variable 
            cell = 1; % Number of cells to move through dataSet
 
            % Populates dataSet with data or NaN
            for ind = 1:length(dateInd) % For all dates  
                dataSet(:, 1) = timeseries; % Populates firts column of datset with date data 
                if dateInd(ind,1) == 1 % If emissions data exists 
                   dataSet(ind,2) = dailymean(cell,1); % Populate template with daily mean SO2 emission rate 
                   dataSet(ind,3) = dailysd(cell,:); % Populate template with standard deviation of SO2 emission rate.. etc. 
                   dataSet(ind,4) = daily25(cell,:); 
                   dataSet(ind,5) = daily50(cell,:); 
                   dataSet(ind,6) = daily75(cell,:); 
                   dataSet(ind,7) = plumespeedmean(cell,:);  
                   dataSet(ind,8) = plumespeedsd(cell,:); 
                   dataSet(ind,9) = plumedirmean(cell,:); 
                   dataSet(ind,10) = plumedirsd(cell,:); 
                   dataSet(ind,11) = plumealtmean(cell,:); 
                   dataSet(ind,12) = plumealtsd(cell,:); 
                   dataSet(ind,13) = plumedistmean(cell,:); 
                   dataSet(ind,14) = plumedistsd(cell,:); 
                   dataSet(ind,15) = plumewidthmean(cell,:); 
                   dataSet(ind,16) = plumewidthsd(cell,:); 
                   dataSet(ind,17) = cloudcovmean(cell,:); 
                   dataSet(ind,18) = cloudcovsd(cell,:); 
                   dataSet(ind,19) = totmeas(cell,:); 
                   dataSet(ind,20) = validmeas(cell,:); 
                   cell = cell + 1; % Moves row on  
                elseif dateInd(ind, 1) == 0 % If no emissions data is available for corresponding date
                   dataSet(ind,2:end) = NaN; % Populate template with 'NaN'
                else
                end 
            end 
 
            % FIGURE - PLOTS TIME SERIES OF DAILY MEAN SO2 EMISSION WITH STANDARD DEVIATION AND EUPTIVE HISTORY
            subplot(7,4,asp)
            set(gcf,'position',[x0, y0, wX, hY]);
            yyaxis left % Daily mean observed SO2 emission and mean plume speed used with standard deviation
            es = errorbar(dataSet(:,1), dataSet(:,2), dataSet(:,3), '.', 'CapSize', 0); hold on; es.MarkerSize = 4; es.LineWidth = 0.5; es.Color = colSO2; hold on;  
            set(gca,'ycolor','k') 
            xlim([min(dataSet(:,1))-20 max(dataSet(:,1))+20]); datetick('x', 'yyyy', 'keeplimits'); 
            ylabel('SO_2 emission (kg s^-^1)'); 
            ylim([0 (max(dataSet(:,2)) + max(dataSet(:,3)))]);
            
             % ERUPTIVE HISTORY 
            fileNameStrGvp = [vName fileTypeGvp]; % Determines filename according to volcano
            inDirGvp = fullfile(dirGvp, fileNameStrGvp); % Determines full directory to access data 
            exOut = exist(inDirGvp, 'file'); 
            if exOut == 2
                    [stDate, spDate, ~, VEI, ~, ~] = textread(inDirGvp, '%s%s%s%s%s%s', 'headerlines', 1, 'delimiter', ','); % Loads eruption history data 
                    exO = isempty(VEI);
                    if exO == 0
                        stDate = string(stDate); stDate = datenum(stDate, formatInGVP); % Converts start date to string and then to numeric form based on format 
                        spDate = string(spDate); spDate = datenum(spDate, formatInGVP); % Converts stop date to string and then to numeric form based on format 
                        VEI = str2double(VEI); % Converts VEI data to numeric 
                        yyaxis right % Eruption history
                        Width = spDate - stDate;
                        Width(Width <= 0) = minWidth; % If eruption is single event, eruption duration set to minimum value 
                        VEIplot = VEI+1; % Plots VEI + 1 so VEI of '0' (i.e., dome eruption) remain visible on plot
                        for widIndx = 1:length(VEIplot) 
                            pos = [stDate(widIndx), 0, Width(widIndx), VEIplot(widIndx)];
                            rectangle('Position', pos,'LineWidth', 2,'LineStyle', '-', 'EdgeColor', 'None', 'FaceColor', colVEI); hold on % Plots rectangle according to eruption duration 
                        end
                       % ylabel('VEI'); 
                       % Fig = gca; 
                       %  set(Fig,'ycolor','k');
                       %  ylim([0 max(VEI)]); 
                       %  yt = 0:1:max(VEI); 
                       %  Fig.YTick = yt;
                       %  Fig.YTickLabel = yt+1; 
                    else
                          yyaxis right % Eruption
                       % Fig = gca; 
                       % ylabel('VEI');
                       % ylim([0 5]);
                       % Fig.YTick = [1, 2, 3, 4, 5];
                       % Fig.YTickLabel = ["0", "1", "2", "3", "4"]; 
                       % set(Fig,'ycolor','k');
                    end 
            else
            end 
            Fig = gca; 
            set(Fig,'ycolor','k');
            ylabel('VEI');
            ylim([0 5]);
            Fig.YTick = [1, 2, 3, 4, 5];
            Fig.YTickLabel = ["0", "1", "2", "3", "4"]; 
            set(Fig,'ycolor','k');
            vn = string(vName); 
            title(sprintf('%s', vn)); 
            % Legend 
            % dummyv = line(NaN, NaN, 'LineWidth',2, 'LineStyle','-'); dummyv.Color = colVEI; % Dummy line for display in legend (VEI)
            % legend([es, dummyv],'Daily mean observed SO_2 emission ¬¨¬± 1\sigma', 'Confirmed eruption', 'Location', 'northoutside');
            Fig = gca; Fig.FontSize = 13; set(gcf,'color','w');
            
            % SAVES FIGURE 
            saveas(Fig, fullfile(outDirFig, sprintf('%s_timeseriesSO2.fig', vn))); % Saves figure
 
            % SAVES VARIABLES
            fname = fullfile(outDirMat, sprintf('%s', vn)); % Defines name of results file according to volcano
            save(fname, 'vn', 'startDate', 'endDate', 'N', 'dataSet');
            
            text(5, max(dataSet(:,2)+2),'(a)','FontSize',12, 'FontWeight','bold');hold on;
            
            % DISPLAYS MESSAGE TO COMMAND LINE
            fprintf('Date file created for %s\n', vn') % Notifies user that .mat file created
            asp = asp+1; 
        else
            % asp = asp;
            vn = string(vName); 
            fprintf('%s has too few datapoints\n', vn); 
        end      
end 