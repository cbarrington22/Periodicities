% 'lombScargleBs' function to CALCULATES LOMB-SCARGLE POWER SPECTRAL DENSITY OF BOOTSTRAPPED DATA (PSD) and FALSE ALARM PROBABILITIES (FAP) defined by Pd for all parameters in <volcano_bsMatrix.mat> 
       % This function uses the 'plomb' function with the maximum frequency (Nf) and oversampling factor (ofac) defined 
            % It checks the returned frequency grid and false alarm probability thresholds are equal across parameters 
            % This function calculates the PSD for all parameters contained in <volcano_bsMatrix.mat> and saves it in <volcano_psdLS.mat> 
            % This function calculates the median and standard deviation at each frequency for parameters contained in <volcano_bsMatrix.mat> and saves the output in <volcano_msdLS.mat> 
        % Note: A warning has been suppressed which indicates a parameter has no variance. This is likely due to a constant value for the plume altitude being used but may not be the case for all volcanoes
       
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged 
 
function [] = lombScargleBs(bsMatrix, dataSet, Nf, ofac, Pd, vn, outDirMat, ext2bs)
 
         % PRE-ALLOCATES SPACE
         % Determines sizes and pre-allocates space 
         [~, ncol, npages] = size(bsMatrix);   % Determines number of columns and number of pages for 3D array (i.e. number of bootstrap runs and number of parameters)
 
         % Runs Lomb-Scargle analysis once to obtain size of output parameters 
         % For the first bootstrapped sample and the first parameter, calculates Lomb Scargle power spectral density and false alarm probability thresholds  
         [pxx, f, pth] = plomb(bsMatrix(:,1,1), dataSet(:,1), Nf, ofac, 'normalized', 'Pd', Pd); 
        
         % Pre-allocates space for PSD ouput 
         pxxMasterBs = zeros(length(pxx), ncol); pxxMasterBs(:,:,npages) = zeros(size(pxxMasterBs));
 
         % Pre-allocates space for frequency grid output 
         fMasterBs = zeros(length(f), ncol); fMasterBs(:,:,npages) = zeros(size(fMasterBs));
        
         % Pre-allocates space for false alarm probability thresholds output 
         pthMasterBs = zeros(length(pth), ncol); pthMasterBs(:,:,npages) = zeros(size(pthMasterBs));
         
         % Pre-allocates space for calculated median and standrad deviation 
         msdMaster = zeros(length(pxx), 2); msdMaster(:,:,npages) = zeros(size(msdMaster));
 
         % CALCULATES PSD
         for pg = 1:npages % For each parameter 
             for c = 1:ncol % And each bootstrapped sample
                 % Calculates Lomb-Scargle periodogram and stores PSD, frequency grid and FAP threshold data
                 [pxxMasterBs(:, c, pg), fMasterBs(:, c, pg), pthMasterBs(:, c, pg)] = plomb(bsMatrix(:, c, pg), dataSet(:,1), Nf, ofac, 'normalized', 'Pd', Pd); 
             end 
             % For each parameter only 
             % Finds median and standard deviation for each frequency 
             % Computes the median of each row  
             msdMaster(:, 1, pg) = median(pxxMasterBs(:, :, pg), 2);
             % Computes the standard deviation of each row 
             % Y = std(X, W, DIM) 
             % A weight of 0 normalizes by N-1, std(X ,0) is the same as std(X)
             msdMaster(:, 2, pg) = std(pxxMasterBs(:, :, pg), 0, 2);
         end 
        
         % CHECK RETURNED FREQUENCY GRID AND FAP THRESHOLDS ARE THE SAME FOR ALL PARAMETERS 
         % isequal(A,B) returns logical 1 (TRUE) if arrays A and B are the same size and contain the same values
         tf = isequal(fMasterBs(:,:,1), fMasterBs(:,:,2), fMasterBs(:,:,3), fMasterBs(:,:,4), fMasterBs(:,:,5), fMasterBs(:,:,6), fMasterBs(:,:,7)); % Frequency grid 
         tp = isequal(pthMasterBs(:,:,1), pthMasterBs(:,:,2), pthMasterBs(:,:,3), pthMasterBs(:,:,4), pthMasterBs(:,:,5), pthMasterBs(:,:,6), pthMasterBs(:,:,7)); % Checks FAP thresholds
       
         if tf == 1 && tp == 1 % If frequency grid and FAP thresholds are the same accross parameters
            % Saves variables as .mat file 
            fname = fullfile(outDirMat, sprintf('%s%s', vn, ext2bs)); % Defines name of results file according to volcano
            save(fname, 'vn', 'dataSet', 'pxxMasterBs', 'fMasterBs', 'pthMasterBs', 'msdMaster');       
            fprintf('Median and standard deviation of PSD calculated from bootstrapped paramaters at %s\n', vn); % Notifies user that .mat file created 
        else  
            fprintf('Warning: Frequency grid and FAP thresholds for %s not equal for all parameters.. .mat file not saved\n', vn);  
        end       
end