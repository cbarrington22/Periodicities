% 'plotLSSyn' function to PLOT PSD FOR SYNTHETIC SIGNALS  
        % Converts frequency data to period (days)
        % Displays periodicities within Nf and lim (for example, 2 days to number of days equal to 4 cycles per time series) 
        % Function saves figure in the directory 'outDirSyn', <volcano_SynPsdLS.fig>  
 
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged 
 
function [] = plotLSSyn(pxxMaster, fMaster, pthMaster, dataSet, deltaT, lim, p1, p2, p3, snr, colSyn, Nf, Pd, vn, outDirSyn, extSyn,  x0, y0, hY, wX)
         
        % Creates strings for use in legend
        p1str = num2str(p1);
        p2str = num2str(p2);
        p3str = num2str(p3);        
        
        t = ones(length(fMaster), 1); 
        
        % LOOPS THROUGH EACH SYNTHETIC SIGNAL 
        for syn = 1:width(pxxMaster)
            figure % ('visible','off'); 
            x = t./(fMaster(:,syn));
            y = pxxMaster(:,syn);
            p = plot(x, y); p.Color = colSyn; p.LineWidth = 1;
            ylabel('PSD estimate');
            % ylim([0 max(y)]); 
            set(gcf,'color','w');
            a = yline(pthMaster(1,syn),':'); a.Color = [0.5 0 0.1]; a.LineWidth = 1;hold on;
            b = yline(pthMaster(2,syn),'--'); b.Color = [0.5 0 0.1]; b.LineWidth = 1;
            c = yline(pthMaster(3,syn),'-'); c.Color = [0.7 0 0]; c.LineWidth = 1;
            d = yline(pthMaster(4,syn),'-'); d.Color = [1 0 0]; d.LineWidth = 1;
            cy = length(dataSet)/lim;
            xlim([min(deltaT/Nf) max(cy)]); xlabel('Period (days)');
            text(cy-40 * [1 1 1 1], pthMaster(:,syn)+.2, [num2str((((Pd)') * 100)), repmat('%', [4,1])], 'FontSize', 12);
            set(gcf,'position',[x0,y0,wX,hY])
            Fig = gca; Fig.FontSize = 14; Fig.XMinorTick = 'on';
            if syn == 1 
               legend(sprintf('%s day, SNR = %d', p1str, snr));   
            elseif syn == 2 
               legend(sprintf('%s and %s day, SNR = %d', p2str, p3str, snr)); 
            elseif syn == 3 
               legend(sprintf('%s, %s and %s day, SNR = %d', p1str, p2str, p3str, snr)); 
            else 
               legend('Random signal'); 
            end 
            % SAVES FIGURE
            saveas(Fig, fullfile(outDirSyn, sprintf('%s_%s.fig', vn, extSyn))); % Saves figure    
        end 
        % Notifies user figure saved
        fprintf('Lomb-Scargle periodogram of synthetic signal with %s timestamp saved\n', vn) 

end 