% 'lombScargleSyn' function to CALCULATE LOMB-SCARGLE POWER SPECTRAL DENSITY (PSD) for each synthetic signal and false alarm probabilities defined by Pd
        % This function uses the 'plomb' function with the maximum frequency (Nf) and oversampling factor (ofac) defined 
        % This function saves the Lomb-Scargle periodogram for each synthetic signal in the directory 'outDirFig', <volcano_synthetic<number>_LS.fig>
 
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged 
 
function [pxxMaster, fMaster, pthMaster] = lombScargleSyn(sOut, dataSet, Nf, ofac, Pd, vn, outDirMat, extSyn)
         
         % PRE-ALLOCATES SPACE
         % Runs Lomb-Scargle analysis once to obtain size of output parameters 
          [pxx, f, pth] = plomb(sOut(:,1), dataSet(:,1), Nf, ofac, 'normalized', 'Pd', Pd); 
 
         % Pre-allocates space for PSD output 
         pxxMaster = zeros(length(pxx), width(sOut)); 
 
         % Pre-allocates space for frequency grid output 
         fMaster = zeros(length(f), width(sOut)); 
        
         % Pre-allocates space for false alarm probability thresholds output 
         pthMaster = zeros(length(pth), width(sOut)); 
 
         % CALCULATES PSD
         for syn = 1:width(sOut) % For each synthetic signal  
             % Calculates Lomb-Scargle periodogram and stores PSD, frequency grid and FAP threshold data
             [pxxMaster(:,syn), fMaster(:,syn), pthMaster(:,syn)] = plomb(sOut(:,syn), dataSet(:,1), Nf, ofac, 'normalized', 'Pd', Pd); 
         end
         
         % CHECK RETURNED FREQUENCY GRID AND FAP THRESHOLDS ARE THE SAME FOR ALL PARAMETERS
         % isequal(A,B) returns logical 1 (TRUE) if arrays A and B are the same size and contain the same values
         tf = isequal(fMaster(:,1), fMaster(:,2), fMaster(:,3), fMaster(:,4)); % Frequency grid 
         tp = isequal(pthMaster(:,1), pthMaster(:,2), pthMaster(:,3), pthMaster(:,4)); % Checks FAP thresholds
         
         if tf == 1 && tp == 1 % If frequency grid and FAP thresholds are the same across synthetic signals
            % Saves variables as .mat file 
            fname = fullfile(outDirMat, sprintf('%s%s', vn, extSyn)); % Defines name of results file according to volcano
            save(fname, 'vn', 'dataSet', 'pxxMaster', 'fMaster', 'pthMaster');       
            fprintf('Lomb-Scargle complete synthetic signals resampled with %s timestamp\n', vn); % Notifies user that .mat file created 
         else  
            fprintf('Warning: Frequency grid and FAP thresholds for %s not equal for all synthetic signals.. .mat file not saved\n', vn);  
         end   
         
end