% 'plotPSDplumespeed' function to PLOTS THE PSD ESTIMATES OF SO2 EMISSION RATE AGAINST THE PSD ESTIMATES OF PLUME SPEED
        % Function saves figure in the directory 'outDirFig', <volcano_PSDxy.fig>
        
% Created by C. BARRINGTON, March 2022 
% Modifications have not been logged 
 
function [asp] = plotPSDplumespeed(msdMaster, pthMasterBs, colSD, colSO2, Pd, vn, outDirFig, dataSet, deltaT, Nf, lim, fMasterBs, asp)
 
        maxP = length(dataSet)/lim;
 
        pgSO2 = 1; 
        pgPS = 2; 
        med = 1;
        sd = 2; 
        % Converts fMasterBs to day so comparable with maxP
        t = ones(length(fMasterBs(:, 1, 1)),1); 
        x = t./fMasterBs(:,1,1);
 
        % FIGURE
        figure;
        subplot(1,2,asp)
        % EXTRACTS DATA WITHIN PERIODS OF INTEREST  
        FREQQ = fMasterBs(:, 1, 1);
        FREQQx = t./FREQQ;
        ofInt = find(FREQQx <= maxP);
        freq = FREQQx(ofInt, :); % Periods of interest 
       
        e = errorbar(msdMaster(ofInt,med,pgPS), msdMaster(ofInt,med,pgSO2), msdMaster(ofInt,sd,pgSO2), msdMaster(ofInt,sd,pgSO2),msdMaster(ofInt,sd,pgPS), msdMaster(ofInt,sd,pgPS),'.', 'CapSize', 1); hold on; 
        e.Color = colSD;
        p = plot(msdMaster(ofInt,med,pgPS), msdMaster(ofInt,med,pgSO2), '.'); p.Color = colSO2;
 
        a = yline(pthMasterBs(1,1,2),':');a.Color = [0.5 0 0.1]; a.LineWidth = 1;hold on;
        b = yline(pthMasterBs(2,1,2),'--');  b.Color = [0.5 0 0.1]; b.LineWidth = 1;
        c = yline(pthMasterBs(3,1,2),'-'); c.Color = [0.7 0 0]; c.LineWidth = 1;
        d = yline(pthMasterBs(4,1,2),'-'); d.Color = [1 0 0]; d.LineWidth = 1;
        
        a = xline(pthMasterBs(1,1,1),':'); a.Color = [0.5 0 0.1]; a.LineWidth = 1;hold on;
        b = xline(pthMasterBs(2,1,2),'--'); b.Color = [0.5 0 0.1]; b.LineWidth = 1;
        c = xline(pthMasterBs(3,1,1),'-'); c.Color = [0.7 0 0]; c.LineWidth = 1;
        d = xline(pthMasterBs(4,1,1),'-'); d.Color = [1 0 0]; d.LineWidth = 1;
        % h = text(pthMasterBs(:,1,1)+.2, 1.3 * [1 1 1 1], [num2str((((Pd)') * 100)), repmat('%', [4,1])], 'FontSize', 11);
        % set(h, 'Rotation', 270);
        title(sprintf('%s', vn));
        % xlabel('Lomb-Scargle PSD plume speed');
        % ylabel(sprintf('Lomb-Scargle PSD\n SO_2 emission rate'));
        set(gcf,'color','w');
        maxX = max(msdMaster(ofInt,med,pgPS)); % +max(msdMaster(:,sd,pgPS))); % maximum on x axis
        maxY = max(msdMaster(ofInt,med,pgSO2)); % +max(msdMaster(:,sd,pgSO2))); % maximum on y axis 
        if maxX > pthMasterBs(1,1,1) || maxY > pthMasterBs(1,1,1) % if maximum of either axis is greater than the 50% threshold 
            if maxX > maxY % and x axis is greater than y 
                xlim([0 (maxX+max(msdMaster(ofInt,sd,pgPS)))+1]); % set both axis to x axis limit (maximum x axis which is > 50% threshold) 
                ylim([0 (maxX+max(msdMaster(ofInt,sd,pgPS)))+1]);  
            elseif maxY > maxX % and y axis is greater than x
                xlim([0 (maxY+max(msdMaster(ofInt,sd,pgSO2)))+1]); % set both axis to x axis limit (maximum x axis which is > 50% threshold) 
                ylim([0 (maxY+max(msdMaster(ofInt,sd,pgSO2)))+1]); 
            end 
        Fig = gca;
        YLIM = Fig.YLim;
            for in = 1:4 
                if pthMasterBs(in,1,2) < max(YLIM)
                   text(0.3 * 1, pthMasterBs(in,1,2)+.5, [num2str((((Pd(in))') * 100)), repmat('%', [1,1])], 'FontSize', 10);
                end 
            end 
        else % but if max x or y axis isn't greater than the 50% threshold       
            xlim([0 pthMasterBs(1,1,1)+1]); % Set axis limit to show the 50% threshold 
            ylim([0 pthMasterBs(1,1,1)+1]);  
            text(0.3 * 1, pthMasterBs(1,1,2)+.25, [num2str((((Pd(1))') * 100)), repmat('%', [1,1])], 'FontSize', 10);
            % end
        end
        % Fig = gca;
        % YLIM = Fig.YLim;
        % for in = 1:4 
        %     if pthMasterBs(in,1,2) < max(YLIM)
        %        text(0.3 * 1, pthMasterBs(in,1,2)+.5, [num2str((((Pd(in))') * 100)), repmat('%', [1,1])], 'FontSize', 10);
        %     end 
        % end 
        set(gca,'FontSize',11)     
        xlabel(sprintf('Lomb-Scargle PSD\nplume speed'), 'FontSize', 11);
        ylabel(sprintf('Lomb-Scargle PSD\nSO_2 emission rate'), 'FontSize', 11);
        % SAVES FIGURE
        Fig = gca;
        saveas(Fig, fullfile(outDirFig, sprintf('%s_PSDSO2PlumeSpeed.fig', vn))); % Saves figure
        fprintf('PSD plot for %s saved\n', vn) % 
        asp = asp+1;
 
end 